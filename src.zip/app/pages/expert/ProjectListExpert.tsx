import { useState, useEffect } from "react";
import { Link, useOutletContext } from "react-router-dom";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../../components/ui/card";
import { Button } from "../../components/ui/button";
import { Badge } from "../../components/ui/badge";
import { Input } from "../../components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../../components/ui/select";
import { Search, Bell, Building2, FileText, TrendingUp } from "lucide-react";

export function ProjectListExpert() {
  const { setUser } = useOutletContext<{ user: any; setUser: (user: any) => void }>();
  const [searchTerm, setSearchTerm] = useState("");
  const [filterType, setFilterType] = useState("all");

  // 컴포넌트 마운트 시 전문가로 user 설정
  useEffect(() => {
    setUser({ type: "expert", name: "전문가" });
  }, [setUser]);

  // 데모 데이터
  const projects = [
    {
      id: 1,
      title: "건설업 일반건설업(토목) 신규 면허 취득",
      industry: "건설업",
      type: "필요 면허",
      businessType: "법인 사업자",
      classification: "신규",
      requiredLicense: "일반건설업(토목공사업)",
      currentIndustry: "없음",
      assetScale: "50억원",
      bids: 5,
      postedDate: "2026-04-01",
      isNew: true,
    },
    {
      id: 2,
      title: "전기공사업 실태조사 의뢰",
      industry: "전기공사업",
      type: "실태 조사",
      businessType: "법인 사업자",
      currentLicense: "전기공사업 면허",
      assetScale: "30억원",
      bids: 3,
      postedDate: "2026-04-02",
      isNew: true,
    },
    {
      id: 3,
      title: "정보통신공사업 면허 추가 등록",
      industry: "정보통신공사업",
      type: "필요 면허",
      businessType: "개인 사업자",
      classification: "추가",
      requiredLicense: "정보통신공사업",
      currentIndustry: "비 건설업 관련 (IT서비스)",
      assetScale: "15억원",
      bids: 7,
      postedDate: "2026-03-28",
      isNew: false,
    },
    {
      id: 4,
      title: "소방시설공사업 자본금 변동 진단",
      industry: "소방시설공사업",
      type: "기타",
      businessType: "법인 사업자",
      reason: "자본금 변동",
      assetScale: "20억원",
      bids: 2,
      postedDate: "2026-04-03",
      isNew: true,
    },
    {
      id: 5,
      title: "건설업 전문건설업(실내건축) 면허 신규",
      industry: "건설업",
      type: "필요 면허",
      businessType: "창업 예정",
      classification: "신규",
      requiredLicense: "전문건설업(실내건축공사업)",
      currentIndustry: "없음",
      assetScale: "-",
      bids: 4,
      postedDate: "2026-04-04",
      isNew: false,
    },
    {
      id: 6,
      title: "의약품도매상 실태조사",
      industry: "의약품도매상",
      type: "실태 조사",
      businessType: "법인 사업자",
      currentLicense: "의약품도매업 면허",
      assetScale: "15억원",
      bids: 1,
      postedDate: "2026-04-05",
      isNew: true,
    },
    {
      id: 7,
      title: "전기공사업 주기적 신고 대행",
      industry: "전기공사업",
      type: "주기적 신고",
      businessType: "법인 사업자",
      assetScale: "40억원",
      bids: 6,
      postedDate: "2026-03-30",
      isNew: false,
    },
    {
      id: 8,
      title: "정보통신공사업 합병 진단",
      industry: "정보통신공사업",
      type: "기타",
      businessType: "법인 사업자",
      reason: "합병",
      assetScale: "25억원",
      bids: 3,
      postedDate: "2026-04-01",
      isNew: false,
    },
  ];

  // 필터링된 의뢰
  const filteredProjects = projects.filter((project) => {
    const matchesSearch =
      project.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      project.industry.toLowerCase().includes(searchTerm.toLowerCase()) ||
      project.type.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = filterType === "all" || project.type === filterType;
    return matchesSearch && matchesType;
  });

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl mb-2">공고 목록</h1>
          <p className="text-gray-600">관심있는 의뢰에 입찰하세요.</p>
        </div>
        <Button variant="outline" className="gap-2">
          <Bell className="h-4 w-4" />
          알림 서비스 (유료)
        </Button>
      </div>

      {/* 검색 및 필터 */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input
                placeholder="의뢰 검색..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={filterType} onValueChange={setFilterType}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="전체" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">전체</SelectItem>
                <SelectItem value="필요 면허">필요 면허</SelectItem>
                <SelectItem value="실태 조사">실태 조사</SelectItem>
                <SelectItem value="주기적 신고">주기적 신고</SelectItem>
                <SelectItem value="기타">기타</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* 공고 목록 */}
      <div className="grid gap-4">
        {filteredProjects.map((project) => {
          // 공고 유형에 따라 표시할 정보 결정
          const getProjectDetails = () => {
            const details = [];
            
            // 사업자 유형은 항상 표시
            details.push({
              icon: Building2,
              label: project.businessType
            });

            // 필요 면허 유형
            if (project.type === "필요 면허") {
              if (project.classification) {
                details.push({
                  icon: FileText,
                  label: `구분: ${project.classification}`
                });
              }
              if (project.requiredLicense) {
                details.push({
                  icon: FileText,
                  label: `필요 면허: ${project.requiredLicense}`
                });
              }
              if (project.currentIndustry) {
                details.push({
                  icon: TrendingUp,
                  label: `현재 업종: ${project.currentIndustry}`
                });
              }
            }

            // 실태 조사 유형
            if (project.type === "실태 조사") {
              if (project.currentLicense) {
                details.push({
                  icon: FileText,
                  label: `보유 면허: ${project.currentLicense}`
                });
              }
            }

            // 주기적 신고 유형
            if (project.type === "주기적 신고") {
              // 사업자 유형만 표시 (이미 추가됨)
            }

            // 기타 유형
            if (project.type === "기타") {
              if (project.reason) {
                details.push({
                  icon: FileText,
                  label: `사유: ${project.reason}`
                });
              }
            }

            // 자산 규모 (없음이 아닌 경우만)
            if (project.assetScale && project.assetScale !== "-") {
              details.push({
                icon: TrendingUp,
                label: `자산 규모: ${project.assetScale}`
              });
            }

            return details;
          };

          const details = getProjectDetails();

          return (
            <Card key={project.id} className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <Badge variant="outline" className="bg-teal-50 text-teal-700 border-teal-200">
                        {project.industry}
                      </Badge>
                      <Badge variant="outline">{project.type}</Badge>
                      {project.isNew && (
                        <Badge className="bg-red-100 text-red-700">NEW</Badge>
                      )}
                      <span className="text-sm text-gray-500">
                        {project.postedDate} 등록
                      </span>
                    </div>
                    <CardTitle className="text-xl mb-2">{project.title}</CardTitle>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                {/* 의뢰인이 입력한 정보만 표시 */}
                <div className="grid md:grid-cols-2 gap-3 mb-4 bg-gray-50 p-4 rounded-lg">
                  {details.map((detail, index) => (
                    <div key={index} className="flex items-center gap-2 text-sm text-gray-700">
                      <detail.icon className="h-4 w-4 text-teal-600" />
                      <span>{detail.label}</span>
                    </div>
                  ))}
                  <div className="flex items-center gap-2 text-sm text-gray-700">
                    <Bell className="h-4 w-4 text-teal-600" />
                    <span className="font-medium">현재 입찰: {project.bids}개</span>
                  </div>
                </div>

                <div className="flex gap-2">
                  <Button asChild variant="outline" size="sm">
                    <Link to={`/expert/projects/${project.id}`}>상세보기</Link>
                  </Button>
                  <Button asChild size="sm" className="bg-teal-600 hover:bg-teal-700">
                    <Link to={`/expert/projects/${project.id}`}>입찰하기</Link>
                  </Button>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {filteredProjects.length === 0 && (
        <Card>
          <CardContent className="py-12 text-center">
            <p className="text-gray-600">검색 결과가 없습니다.</p>
          </CardContent>
        </Card>
      )}

      {/* 알림 서비스 안내 */}
      <Card className="bg-teal-50 border-teal-200">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-teal-900">
            <Bell className="h-5 w-5 text-teal-600" />
            알림 서비스 (유료)
          </CardTitle>
          <CardDescription className="text-teal-800">
            새로운 공고가 등록되면 즉시 알림을 받을 수 있습니다. 경쟁자보다 빠르게 입찰하세요!
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Button className="bg-teal-600 hover:bg-teal-700">알림 서비스 신청하기</Button>
        </CardContent>
      </Card>
    </div>
  );
}