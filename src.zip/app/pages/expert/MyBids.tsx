import { Link } from "react-router-dom";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../../components/ui/card";
import { Button } from "../../components/ui/button";
import { Badge } from "../../components/ui/badge";
import { Calendar, DollarSign, Clock, Copy } from "lucide-react";
import { toast } from "sonner";

export function MyBids() {
  // 데모 데이터
  const bids = [
    {
      id: 1,
      projectId: 1,
      projectTitle: "식품 제조업 영업 면허 취득",
      myBid: "₩2,500,000",
      estimatedDays: 30,
      status: "대기 중",
      bidDate: "2026-04-05",
      totalBids: 5,
    },
    {
      id: 2,
      projectId: 2,
      projectTitle: "제조업 실태 조사",
      myBid: "₩4,800,000",
      estimatedDays: 25,
      status: "선정됨",
      bidDate: "2026-04-03",
      totalBids: 3,
      clientContact: "010-1234-5678",
    },
    {
      id: 3,
      projectId: 4,
      projectTitle: "건설업 면허 신청 대행",
      myBid: "₩3,900,000",
      estimatedDays: 28,
      status: "대기 중",
      bidDate: "2026-04-04",
      totalBids: 7,
    },
    {
      id: 4,
      projectId: 5,
      projectTitle: "물류 센터 안전 진단",
      myBid: "₩6,200,000",
      estimatedDays: 35,
      status: "선정됨",
      bidDate: "2026-04-06",
      totalBids: 2,
      clientContact: "010-9876-5432",
    },
    {
      id: 5,
      projectId: 3,
      projectTitle: "환경 관련 인증 컨설팅",
      myBid: "₩6,800,000",
      estimatedDays: 40,
      status: "거절됨",
      bidDate: "2026-03-30",
      totalBids: 4,
    },
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case "선정됨":
        return "bg-green-100 text-green-700";
      case "대기 중":
        return "bg-yellow-100 text-yellow-700";
      case "거절됨":
        return "bg-gray-100 text-gray-700";
      default:
        return "bg-blue-100 text-blue-700";
    }
  };

  const activeBids = bids.filter((bid) => bid.status === "대기 중" || bid.status === "선정됨");
  const pastBids = bids.filter((bid) => bid.status === "거절됨");

  const handleCopyContact = (contact: string) => {
    navigator.clipboard.writeText(contact).then(() => {
      toast.success("연락처가 클립보드에 복사되었습니다!");
    }).catch(() => {
      toast.error("연락처 복사에 실패했습니다.");
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl mb-2">내 입찰 내역</h1>
          <p className="text-gray-600">제출한 입찰을 관리하고 상태를 확인하세요.</p>
        </div>
        <Button asChild>
          <Link to="/expert/projects">새 공고 찾기</Link>
        </Button>
      </div>

      {/* 통계 */}
      <div className="grid md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm">활성 입찰</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl">
              {bids.filter((b) => b.status === "대기 중").length}
            </div>
            <p className="text-xs text-gray-600 mt-1">대기 중</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm">선정된 의뢰</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl">
              {bids.filter((b) => b.status === "선정됨").length}
            </div>
            <p className="text-xs text-gray-600 mt-1">진행 중</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm">입찰 성공률</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl">
              {Math.round(
                (bids.filter((b) => b.status === "선정됨").length / bids.length) * 100
              )}
              %
            </div>
            <p className="text-xs text-gray-600 mt-1">전체 입찰 대비</p>
          </CardContent>
        </Card>
      </div>

      {/* 활성 입찰 */}
      <div>
        <h2 className="text-xl mb-4">활성 입찰</h2>
        <div className="grid gap-4">
          {activeBids.map((bid) => (
            <Card key={bid.id} className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <Badge className={getStatusColor(bid.status)}>{bid.status}</Badge>
                      <span className="text-sm text-gray-500">
                        입찰일: {bid.bidDate}
                      </span>
                    </div>
                    <CardTitle className="text-xl mb-2">{bid.projectTitle}</CardTitle>
                    <CardDescription>
                      현재 {bid.totalBids}개의 입찰이 제출되었습니다.
                    </CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-3 gap-4 mb-4">
                  <div className="flex items-center gap-2 text-sm">
                    <DollarSign className="h-4 w-4 text-gray-600" />
                    <div>
                      <p className="text-gray-600">내 입찰가</p>
                      <p className="font-medium">{bid.myBid}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <Clock className="h-4 w-4 text-gray-600" />
                    <div>
                      <p className="text-gray-600">예상 기간</p>
                      <p className="font-medium">{bid.estimatedDays}일</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <Calendar className="h-4 w-4 text-gray-600" />
                    <div>
                      <p className="text-gray-600">입찰일</p>
                      <p className="font-medium">{bid.bidDate}</p>
                    </div>
                  </div>
                </div>

                {bid.status === "선정됨" && bid.clientContact && (
                  <Card className="bg-green-50 border-green-200 mb-4">
                    <CardContent className="pt-4">
                      <p className="text-sm text-green-900 mb-2">
                        🎉 축하합니다! 의뢰인이 회원님을 선택했습니다.
                      </p>
                      <p className="text-sm text-green-800">
                        의뢰인 연락처: <span className="font-medium">{bid.clientContact}</span>
                      </p>
                      <p className="text-xs text-green-700 mt-1">
                        연락하여 최종 가격을 협상해주세요.
                      </p>
                    </CardContent>
                  </Card>
                )}

                <div className="flex gap-2">
                  <Button asChild variant="outline" size="sm">
                    <Link to={`/expert/projects/${bid.projectId}`}>의뢰 보기</Link>
                  </Button>
                  {bid.status === "선정됨" && bid.clientContact && (
                    <Button 
                      size="sm" 
                      onClick={() => handleCopyContact(bid.clientContact!)}
                      className="gap-2"
                    >
                      <Copy className="h-4 w-4" />
                      의뢰인 연락처 복사하기
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}

          {activeBids.length === 0 && (
            <Card>
              <CardContent className="py-12 text-center">
                <p className="text-gray-600 mb-4">활성 입찰이 없습니다.</p>
                <Button asChild>
                  <Link to="/expert/projects">공고 찾아보기</Link>
                </Button>
              </CardContent>
            </Card>
          )}
        </div>
      </div>

      {/* 이전 입찰 */}
      {pastBids.length > 0 && (
        <div>
          <h2 className="text-xl mb-4">이전 입찰</h2>
          <div className="grid gap-4">
            {pastBids.map((bid) => (
              <Card key={bid.id} className="opacity-75">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <Badge className={getStatusColor(bid.status)}>{bid.status}</Badge>
                        <span className="text-sm text-gray-500">
                          입찰일: {bid.bidDate}
                        </span>
                      </div>
                      <CardTitle className="text-xl">{bid.projectTitle}</CardTitle>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center gap-4 text-sm text-gray-600">
                    <span>입찰가: {bid.myBid}</span>
                    <span>예상 기간: {bid.estimatedDays}일</span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}