import { useState, useEffect } from "react";
import { useParams, useNavigate, Link, useOutletContext } from "react-router-dom";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../../components/ui/card";
import { Button } from "../../components/ui/button";
import { Input } from "../../components/ui/input";
import { Label } from "../../components/ui/label";
import { Textarea } from "../../components/ui/textarea";
import { Badge } from "../../components/ui/badge";
import { Building2, Users, FileText, TrendingUp, MapPin } from "lucide-react";
import { toast } from "sonner";

export function ProjectDetailExpert() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { setUser } = useOutletContext<{ user: any; setUser: (user: any) => void }>();
  const [showBidForm, setShowBidForm] = useState(false);
  const [bidData, setBidData] = useState({
    price: "",
    estimatedDays: "",
    message: "",
  });

  // 컴포넌트 마운트 시 전문가로 user 설정
  useEffect(() => {
    setUser({ type: "expert", name: "전문가" });
  }, [setUser]);

  // 데모 데이터
  const project = {
    id: 1,
    title: "건설업 일반건설업(토목) 신규 면허 취득",
    industry: "건설업",
    type: "필요 면허",
    businessType: "법인 사업자",
    classification: "신규",
    requiredLicense: "일반건설업(토목공사업)",
    currentIndustry: "없음",
    assetScale: "50억원",
    bids: 5,
    status: "입찰 중",
    createdAt: "2026-04-01",
    company: {
      name: "(주)건설개발",
      representative: "김철수",
    },
  };

  const handleBidChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    setBidData({
      ...bidData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmitBid = (e: React.FormEvent) => {
    e.preventDefault();
    toast.success("입찰이 완료되었습니다!");
    setTimeout(() => {
      navigate("/expert/my-bids");
    }, 1500);
  };

  return (
    <div className="space-y-6">
      {/* 헤더 */}
      <div className="flex items-start justify-between">
        <div className="flex-1">
          <div className="flex items-center gap-2 mb-3">
            <Badge variant="outline" className="bg-teal-50 text-teal-700 border-teal-200">
              {project.industry}
            </Badge>
            <Badge variant="outline">{project.type}</Badge>
            <Badge className="bg-green-100 text-green-700">{project.status}</Badge>
          </div>
          <h1 className="text-3xl mb-2">{project.title}</h1>
          <p className="text-gray-600">등록일: {project.createdAt}</p>
        </div>
        <div className="flex gap-2">
          <Button asChild variant="outline">
            <Link to="/expert/projects">목록으로</Link>
          </Button>
          {!showBidForm && (
            <Button className="bg-teal-600 hover:bg-teal-700" onClick={() => setShowBidForm(true)}>입찰하기</Button>
          )}
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* 주요 정보 */}
        <div className="lg:col-span-2 space-y-6">
          {/* 의뢰인이 입력한 정보 */}
          <Card>
            <CardHeader>
              <CardTitle>의뢰 정보</CardTitle>
              <CardDescription>의뢰인이 입력한 상세 정보입니다.</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="grid md:grid-cols-2 gap-4 pb-4 border-b">
                  <div>
                    <p className="text-sm text-gray-600 mb-1">업종</p>
                    <p className="font-medium">{project.industry}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600 mb-1">공고 유형</p>
                    <p className="font-medium">{project.type}</p>
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-4 pb-4 border-b">
                  <div>
                    <p className="text-sm text-gray-600 mb-1">사업자 유형</p>
                    <p className="font-medium">{project.businessType}</p>
                  </div>
                  {project.classification && (
                    <div>
                      <p className="text-sm text-gray-600 mb-1">구분</p>
                      <p className="font-medium">{project.classification}</p>
                    </div>
                  )}
                </div>

                {/* 필요 면허 유형일 때 */}
                {project.type === "필요 면허" && (
                  <>
                    {project.requiredLicense && (
                      <div className="pb-4 border-b">
                        <p className="text-sm text-gray-600 mb-1">필요 면허</p>
                        <p className="font-medium">{project.requiredLicense}</p>
                      </div>
                    )}
                    {project.currentIndustry && (
                      <div className="pb-4 border-b">
                        <p className="text-sm text-gray-600 mb-1">현재 업종</p>
                        <p className="font-medium">{project.currentIndustry}</p>
                      </div>
                    )}
                  </>
                )}

                {/* 실태 조사 유형일 때 */}
                {project.type === "실태 조사" && project.currentLicense && (
                  <div className="pb-4 border-b">
                    <p className="text-sm text-gray-600 mb-1">보유 면허</p>
                    <p className="font-medium">{project.currentLicense}</p>
                  </div>
                )}

                {/* 기타 유형일 때 */}
                {project.type === "기타" && project.reason && (
                  <div className="pb-4 border-b">
                    <p className="text-sm text-gray-600 mb-1">진단 사유</p>
                    <p className="font-medium">{project.reason}</p>
                  </div>
                )}

                {/* 자산 규모 */}
                {project.assetScale && project.assetScale !== "-" && (
                  <div>
                    <p className="text-sm text-gray-600 mb-1">자산 규모</p>
                    <p className="font-medium">{project.assetScale}</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* 입찰 폼 */}
          {showBidForm && (
            <Card className="border-teal-500 border-2">
              <CardHeader>
                <CardTitle>입찰 정보 입력</CardTitle>
                <CardDescription>
                  정확한 정보를 입력해주세요. 입찰가는 협상 전 가격입니다.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmitBid} className="space-y-4">
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="price">
                        입찰가 (원) <span className="text-red-500">*</span>
                      </Label>
                      <Input
                        id="price"
                        name="price"
                        type="number"
                        placeholder="2500000"
                        value={bidData.price}
                        onChange={handleBidChange}
                        required
                      />
                      <p className="text-xs text-gray-600">
                        의뢰인 선택 후 최종 가격 협상이 가능합니다.
                      </p>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="estimatedDays">
                        예상 소요 기간 (일) <span className="text-red-500">*</span>
                      </Label>
                      <Input
                        id="estimatedDays"
                        name="estimatedDays"
                        type="number"
                        placeholder="30"
                        value={bidData.estimatedDays}
                        onChange={handleBidChange}
                        required
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="message">
                      제안 메시지 <span className="text-red-500">*</span>
                    </Label>
                    <Textarea
                      id="message"
                      name="message"
                      placeholder="귀하의 경력과 이 의뢰를 성공적으로 완수할 수 있는 이유를 설명해주세요."
                      rows={6}
                      value={bidData.message}
                      onChange={handleBidChange}
                      required
                    />
                  </div>

                  <div className="flex gap-4">
                    <Button type="submit" className="flex-1 bg-teal-600 hover:bg-teal-700">
                      입찰 제출하기
                    </Button>
                    <Button
                      type="button"
                      variant="outline"
                      className="flex-1"
                      onClick={() => setShowBidForm(false)}
                    >
                      취소
                    </Button>
                  </div>
                </form>
              </CardContent>
            </Card>
          )}
        </div>

        {/* 사이드바 */}
        <div className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>입찰 정보</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-start gap-3">
                <Users className="h-5 w-5 text-teal-600 mt-0.5" />
                <div className="flex-1">
                  <p className="text-sm text-gray-600">현재 입찰 수</p>
                  <p className="font-medium text-lg">{project.bids}개</p>
                  <p className="text-xs text-gray-500 mt-1">
                    경쟁이 치열할수록 빠른 입찰이 유리합니다.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>의뢰 기업 정보</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-start gap-2">
                <Building2 className="h-5 w-5 text-teal-600 mt-0.5" />
                <div className="flex-1">
                  <p className="text-sm text-gray-600">회사명</p>
                  <p className="font-medium">{project.company.name}</p>
                </div>
              </div>
              <div className="pl-7">
                <p className="text-sm text-gray-600">대표자</p>
                <p className="font-medium">{project.company.representative}</p>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-teal-50 border-teal-200">
            <CardContent className="pt-6">
              <h4 className="font-medium text-teal-900 mb-2">입찰 안내</h4>
              <ul className="text-sm text-teal-800 space-y-1">
                <li>• 입찰가는 협상 전 가격입니다</li>
                <li>• 의뢰인이 선택하면 연락처가 공개됩니다</li>
                <li>• 최종 가격은 직접 협상으로 결정됩니다</li>
              </ul>
            </CardContent>
          </Card>

          {!showBidForm && (
            <Button className="w-full bg-teal-600 hover:bg-teal-700" size="lg" onClick={() => setShowBidForm(true)}>
              지금 입찰하기
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}