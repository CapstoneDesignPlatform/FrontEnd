import { useState, useEffect } from "react";
import { useNavigate, useOutletContext } from "react-router-dom";
import { Button } from "../../components/ui/button";
import { Input } from "../../components/ui/input";
import { Label } from "../../components/ui/label";
import { Textarea } from "../../components/ui/textarea";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../../components/ui/card";
import { Badge } from "../../components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../../components/ui/select";
import { CheckCircle2, Upload, FileText, AlertCircle } from "lucide-react";
import { toast } from "sonner";

export function ExpertVerification() {
  const navigate = useNavigate();
  const { setUser } = useOutletContext<{ user: any; setUser: (user: any) => void }>();
  const [verificationStatus, setVerificationStatus] = useState<"pending" | "verified" | "none">("none");
  const [formData, setFormData] = useState({
    licenseType: "",
    licenseNumber: "",
    issueDate: "",
    expertiseArea: "",
    experience: "",
    education: "",
    portfolio: "",
  });

  // 컴포넌트 마운트 시 전문가로 user 설정
  useEffect(() => {
    setUser({ type: "expert", name: "전문가" });
  }, [setUser]);

  const [uploadedFiles, setUploadedFiles] = useState({
    license: null as File | null,
    businessLicense: null as File | null,
  });

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>, type: "license" | "businessLicense") => {
    const file = e.target.files?.[0];
    if (file) {
      setUploadedFiles({
        ...uploadedFiles,
        [type]: file,
      });
      toast.success(`${type === "license" ? "자격증" : "사업자 등록증"} 파일이 업로드되었습니다.`);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // 필수 파일 검증
    if (!uploadedFiles.license) {
      toast.error("자격증 사본을 업로드해주세요.");
      return;
    }
    
    if (!uploadedFiles.businessLicense) {
      toast.error("사업자 등록증을 업로드해주세요.");
      return;
    }

    if (!formData.licenseType) {
      toast.error("자격증 종류를 선택해주세요.");
      return;
    }

    toast.success("전문가 인증 신청이 완료되었습니다!");
    // 인증 신청 완료 후 승인 대기 페이지로 이동
    navigate("/expert/pending");
  };

  return (
    <div className="max-w-3xl space-y-6">
      {/* 인증 상태 */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-2xl">전문가 인증</CardTitle>
              <CardDescription>
                전문가 인증을 완료해야 서비스를 이용하실 수 있습니다.
              </CardDescription>
            </div>
            {verificationStatus === "verified" && (
              <Badge className="bg-green-100 text-green-700 text-base px-4 py-2">
                <CheckCircle2 className="h-5 w-5 mr-2" />
                인증 완료
              </Badge>
            )}
            {verificationStatus === "pending" && (
              <Badge className="bg-yellow-100 text-yellow-700 text-base px-4 py-2">
                검토 중
              </Badge>
            )}
          </div>
        </CardHeader>
      </Card>

      {/* 인증 신청 폼 */}
      {verificationStatus !== "verified" && (
        <Card>
          <CardHeader>
            <CardTitle>인증 정보 입력</CardTitle>
            <CardDescription>정확한 정보를 입력해주세요.</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* 자격증 정보 */}
              <div className="space-y-4">
                <h3 className="font-medium">자격증 정보</h3>
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="licenseType">
                      자격증 종류 <span className="text-red-500">*</span>
                    </Label>
                    <Select
                      value={formData.licenseType}
                      onValueChange={(value) => setFormData({ ...formData, licenseType: value })}
                      disabled={verificationStatus === "pending"}
                    >
                      <SelectTrigger className="w-full">
                        <SelectValue placeholder="자격증을 선택하세요" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="공인회계사">공인회계사</SelectItem>
                        <SelectItem value="세무사">세무사</SelectItem>
                        <SelectItem value="경영지도사">경영지도사</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="licenseNumber">
                      자격증 번호 <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="licenseNumber"
                      name="licenseNumber"
                      placeholder="자격증 번호"
                      value={formData.licenseNumber}
                      onChange={handleChange}
                      required
                      disabled={verificationStatus === "pending"}
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="issueDate">
                    발급일 <span className="text-red-500">*</span>
                  </Label>
                  <Input
                    id="issueDate"
                    name="issueDate"
                    type="date"
                    value={formData.issueDate}
                    onChange={handleChange}
                    required
                    disabled={verificationStatus === "pending"}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="licenseFile">
                    자격증 사본 <span className="text-red-500">*</span>
                  </Label>
                  <label 
                    htmlFor="licenseFile"
                    className="border-2 border-dashed rounded-lg p-6 text-center hover:border-teal-500 transition-colors cursor-pointer block"
                  >
                    {uploadedFiles.license ? (
                      <div className="flex items-center justify-center gap-2">
                        <FileText className="h-6 w-6 text-teal-600" />
                        <span className="text-sm text-teal-600 font-medium">{uploadedFiles.license.name}</span>
                      </div>
                    ) : (
                      <>
                        <Upload className="h-8 w-8 mx-auto mb-2 text-gray-400" />
                        <p className="text-sm text-gray-600">
                          클릭하여 자격증 사본 업로드 (PDF, JPG, PNG)
                        </p>
                      </>
                    )}
                  </label>
                  <Input
                    id="licenseFile"
                    type="file"
                    className="hidden"
                    accept=".pdf,.jpg,.jpeg,.png"
                    onChange={(e) => handleFileUpload(e, "license")}
                    disabled={verificationStatus === "pending"}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="businessLicenseFile">
                    사업자 등록증 <span className="text-red-500">*</span>
                  </Label>
                  <label 
                    htmlFor="businessLicenseFile"
                    className="border-2 border-dashed rounded-lg p-6 text-center hover:border-teal-500 transition-colors cursor-pointer block"
                  >
                    {uploadedFiles.businessLicense ? (
                      <div className="flex items-center justify-center gap-2">
                        <FileText className="h-6 w-6 text-teal-600" />
                        <span className="text-sm text-teal-600 font-medium">{uploadedFiles.businessLicense.name}</span>
                      </div>
                    ) : (
                      <>
                        <Upload className="h-8 w-8 mx-auto mb-2 text-gray-400" />
                        <p className="text-sm text-gray-600">
                          클릭하여 사업자 등록증 업로드 (PDF, JPG, PNG)
                        </p>
                      </>
                    )}
                  </label>
                  <Input
                    id="businessLicenseFile"
                    type="file"
                    className="hidden"
                    accept=".pdf,.jpg,.jpeg,.png"
                    onChange={(e) => handleFileUpload(e, "businessLicense")}
                    disabled={verificationStatus === "pending"}
                  />
                </div>
              </div>

              {/* 경력 정보 */}
              <div className="space-y-4">
                <h3 className="font-medium">경력 정보</h3>
                <div className="space-y-2">
                  <Label htmlFor="expertiseArea">
                    전문 분야 <span className="text-red-500">*</span>
                  </Label>
                  <Input
                    id="expertiseArea"
                    name="expertiseArea"
                    placeholder="예) 식품 관련 면허, 건설업 인허가"
                    value={formData.expertiseArea}
                    onChange={handleChange}
                    required
                    disabled={verificationStatus === "pending"}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="experience">
                    경력 사항 <span className="text-red-500">*</span>
                  </Label>
                  <Textarea
                    id="experience"
                    name="experience"
                    placeholder="주요 경력을 입력해주세요. (회사명, 기간, 주요 업무 등)"
                    rows={5}
                    value={formData.experience}
                    onChange={handleChange}
                    required
                    disabled={verificationStatus === "pending"}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="education">학력</Label>
                  <Input
                    id="education"
                    name="education"
                    placeholder="최종 학력"
                    value={formData.education}
                    onChange={handleChange}
                    disabled={verificationStatus === "pending"}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="portfolio">포트폴리오 / 실적</Label>
                  <Textarea
                    id="portfolio"
                    name="portfolio"
                    placeholder="주요 의뢰나 실적을 입력해주세요."
                    rows={4}
                    value={formData.portfolio}
                    onChange={handleChange}
                    disabled={verificationStatus === "pending"}
                  />
                </div>
              </div>

              {/* 제출 버튼 */}
              {verificationStatus === "none" && (
                <div className="space-y-3">
                  <div className="flex gap-4">
                    <Button type="submit" className="flex-1">
                      인증 신청하기
                    </Button>
                    <Button
                      type="button"
                      variant="outline"
                      className="flex-1"
                      onClick={() => navigate("/expert/dashboard")}
                    >
                      나중에 하기
                    </Button>
                  </div>
                  
                  {/* 테스트용 버튼 */}
                  <Button
                    type="button"
                    variant="secondary"
                    className="w-full bg-gray-200 hover:bg-gray-300 text-gray-700"
                    onClick={() => {
                      toast.success("테스트용: 전문가 인증이 승인되었습니다!");
                      navigate("/expert/projects");
                    }}
                  >
                    🧪 테스트용 다음단계 (바로 공고목록으로)
                  </Button>
                </div>
              )}

              {verificationStatus === "pending" && (
                <Card className="bg-yellow-50 border-yellow-200">
                  <CardContent className="pt-6">
                    <div className="flex items-start gap-3">
                      <FileText className="h-6 w-6 text-yellow-600 flex-shrink-0" />
                      <div>
                        <h4 className="font-medium text-yellow-900 mb-1">
                          검토 중입니다
                        </h4>
                        <p className="text-sm text-yellow-800">
                          제출하신 인증 정보를 검토 중입니다. 1-2일 내에 결과를
                          알려드리겠습니다.
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}
            </form>
          </CardContent>
        </Card>
      )}

      {/* 인증 완료 메시지 */}
      {verificationStatus === "verified" && (
        <Card className="bg-green-50 border-green-200">
          <CardContent className="pt-6">
            <div className="flex items-start gap-3">
              <CheckCircle2 className="h-6 w-6 text-green-600 flex-shrink-0" />
              <div>
                <h4 className="font-medium text-green-900 mb-1">
                  인증이 완료되었습니다!
                </h4>
                <p className="text-sm text-green-800 mb-4">
                  이제 인증 전문가로서 더 많은 기회를 얻을 수 있습니다.
                </p>
                <Button asChild>
                  <a href="/expert/projects">공고 찾아보기</a>
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}